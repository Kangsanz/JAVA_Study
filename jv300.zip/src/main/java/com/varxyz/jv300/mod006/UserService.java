package com.varxyz.jv300.mod006;

public class UserService {

	public void addUser(User user) {
		user.toString();
	}
}
