package com.varxyz.jv300.mod007;

public class UserService {

	public void addUser(User user) {
		user.toString();
	}
}
